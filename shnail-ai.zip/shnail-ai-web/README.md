# Shnail AI — deploy-ready website

This version is designed for **Cloudflare Pages + Pages Functions**, so it can be deployed as a website without running a Node.js server.

## What it contains

- `public/` — website files
- `functions/api/chat.js` — secure server-side AI endpoint
- `functions/api/health.js` — health check
- `_headers` — basic security headers

The OpenAI API key is stored as a Cloudflare secret/environment variable and is never sent to the browser.

## Deploy from Android

The easiest workflow is GitHub + Cloudflare.

### 1. Create a GitHub repository

Create an empty repository, then upload the contents of this ZIP. You can do this from the GitHub mobile website/app.

### 2. Create the Cloudflare Pages project

In Cloudflare:

Workers & Pages → Create application → Pages → Import an existing Git repository.

Use:

- Production branch: `main`
- Build command: `exit 0`
- Build output directory: `public`

Cloudflare Pages Functions are automatically detected from the root `functions/` directory.

### 3. Add your API secret

In your Cloudflare Pages project, open Settings → Environment variables / Functions variables.

Add:

`OPENAI_API_KEY` = your OpenAI API key

Add:

`OPENAI_MODEL` = `gpt-5.6-luna`

Make the API key a secret/encrypted value where Cloudflare offers that option.

### 4. Redeploy

After adding the variables, redeploy the project.

Your site will receive a `*.pages.dev` address.

## Important

Never put your OpenAI API key in `public/app.js`, `index.html`, or any other browser-side file.

## Model

The default model is `gpt-5.6-luna`. Change `OPENAI_MODEL` in Cloudflare if you want another model available to your API project.

## Costs

Cloudflare hosting and OpenAI API usage are separate. The AI requests consume your OpenAI API usage, while Cloudflare Functions have their own limits/pricing.
